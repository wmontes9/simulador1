<div class="col-xs-11 col-sm-13 col-md-12 col-lg-15">
	<head>
	
	<style type="text/css">
		body{
			background: width ;
		}
	</style>
   </head>
<nav style="background-color: rgba(161 182 149);"class="navbar navbar-default navbar-static-top ">
	

	<?php 
    echo "<br> "."\n"; 
    ?>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

   <div class="btn-group" >
        <p>
            <button style="font-size:15px "type="button" id="inicio" class="btn color "><span><i class="fa fa-home"></i> INICIO </span></button>
        </p>  
    </div>
      
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


    <div class="btn-group">
        <p>
            <button style="font-size:15px"type="button" class="btn color" id="descripcion"><span><i class="fa fa-sort" aria-hidden="true"></i> DESCRIPCION  </span></button>
        </p>   
    </div>

      
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

    <div class="btn-group">
        <p>
            <button style="font-size:15px"type="button" class="btn color" id="audiencia">
                <span><i class=" fa fa-group "></i> AUDIENCIA </span>
            </button>
        </p>   
    </div>

      
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


    <div class="btn-group">
        <p>
            <button style="font-size:15px"type="button" class="btn color" id="anexos"><span><i class="fa fa-file-text-o" aria-hidden="true"></i> ANEXOS </span></button>
        </p>  
    </div>
    
      
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;



    <div class="btn-group">
        <p>
            <button style="font-size:15px"type="button" class="btn color" id="actividades"><span><i class="fa fa-briefcase" aria-hidden="true "></i></span> ACTIVIDADES </button>
        </p>  
    </div>

     
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;



    <div class="btn-group">
        <p>
            <button style="font-size:15px"type="button" class="btn color" id="evaluacion"><span><i class="fa fa-forward" aria-hidden="true"></i> EVALUACION </span></button>
        </p>  
    </div>

   
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

    <div class="btn-group">
        <p>
            <button style="width:100px;border: 150px ;border-radius: 20px;"type=" button" class="btn  color" id="salir"><span  style="font-size:20px"></span> SALIR </button>
        </p>  
    </div>
    
    	
    
</nav>
     <?php 
    echo "<br> "."\n"; 
    ?>
    <div class="row">
    	<div class="col-md-6 descripcion" style="display: none;">
    		<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
    	</div>
         <div class="row">
        <div class="col-md-6 audiencia" style="display: none;">
            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
        </div>
       
    	<div class="col-md-6 text-center video">
			<style>
	            video {
	            border-radius: 0px;
	            width: 110%;
	            height: auto;
	            margin-top: 10px;
	            }
	        </style>
	            <video controls poster="" class="img-responsive">
	                <source src="videos/VID-20180911-WA0000.mp4" ></source>
	                <source src="sintel.mp4" ></source>
	                <source src="sintel.webm" ></source>
	                <source src="sintel.ogv" ></source>
	            </video>
</div>
    	<div class="col-md-6">
	    	<div class="competencia">
	        <span>COMPETENCIA</span>
	        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem eaque, eos sed officia rem, numquam, consectetur suscipit animi, eum quaerat hic totam! Aliquam quos deleniti, tempore saepe corporis ea tenetur.</p>
		    </div>
		   
		    <div class="competencia">
		       <span>RESULTADOS DE APRENDISAJE</span>
		       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		       tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		       quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		       </p>
		    </div>
		    
		    <div class="competencia">
		        <span>COMPETENCIA</span>
		        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorem eaque, eos sed officia rem, numquam, consectetur suscipit animi, eum quaerat hic totam! Aliquam quos deleniti, tempore saepe corporis ea tenetur.</p>
		    </div>
    	</div>  

    
    
    &nbsp;&nbsp;
    <footer>
        <div class='define'>
            <p>Contenido del pie de página</p>
          
        </div>
    </footer>

4