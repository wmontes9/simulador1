<table class="table table-responsive table-bordered">
    <thead>
    	<tr>
    	<th colspan="9" class="text-center">Titulo de la tabla</th>
    <tbody>
        <tr>
            <th>ITEMS</th>
            <th colspan="2">empresa 1</th>
            <th colspan="2">enpresa 2</th>
            <th colspan="2">empresa 3</th>
            <th colspan="4">empresa 4</th>
        </tr>
        </tbody>
        </tr>
       <thead>
    
  </thead>
  <tbody>
    
    <tr>
      <th scope="row"></th>
      <td> si </td>
      <td> no </td>
      <td> si </td>
      <td> no</td>
      <td> si </td>
      <td> no </td>
      <td> si </td>
      <td> no </td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
     
  </tbody>
        
    </thead>
    
</table>
    </div>

 
 <table class="table table-responsive table-bordered">
    <thead>
        <tr>
            <th >IMTEM</th>
            <th >Empresa 1</th>
            <th >Empresa 2</th>
            <th >Empresa 3</th>
            <th >Empresa 4</th>
        </tr>
    </thead>
    <tbody>
        <tr>
      <th scope="row"></th>
      <td>puntos</td>
      <td>puntos</td>
      <td>puntos</td>
      <td>puntos</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th scope="row"> total</th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    </tbody>
</table>

 
  <table class="table table-responsive table-bordered">
    <thead>
        <tr>
            <th >IMTEM</th>
            <th >Empresa 1</th>
            <th >Empresa 2</th>
            <th >Empresa 3</th>
            <th >Empresa 4</th>
        </tr>
    </thead>
    <tbody>
        <tr>
      <th scope="row"></th>
      <td>puntos</td>
      <td>puntos</td>
      <td>puntos</td>
      <td>puntos</td>
    </tr>
    <tr>
      <th scope="row"></th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th scope="row"> total</th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    </tbody>
</table>
