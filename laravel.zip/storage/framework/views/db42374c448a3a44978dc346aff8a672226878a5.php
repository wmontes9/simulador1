<?php $__env->startSection("content"); ?>
	<div class="row" id="appControllerDetalle">
		<div class="container">
			<div class="col-xs-12 col-sm-12 col-md-12">
				<!--<input type="hidden" id="idCentro" value="<?php echo e(Session::get('id_center')); ?>"  name="id_center">-->
				<a href="#newDetalleCaso" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
				<div class="clearfix"></div>
				<table class="table table-bordered" style="margin-top: 10px;">
					<tr>
						<td>Id</td>
                        <td>Id_Caso</td>
						<td>Proposito</td>
                        <td>Fecha de elaboración</td>
                        <td>Estado</td>
                        <td>Tiempo promedio</td>
						<td colspan="3">Opciones</td>
					</tr>
					<tr v-for="detalle in detalles">
						<td>{{detalle.id}}</td>
                        <td>{{detalle.id_caso}}</td>
						<td>{{detalle.proposito}}</td>
                        <td>{{detalle.fecha_elaboracion}}</td>
                        <td>{{detalle.estado}}</td>
                        <td>{{detalle.tiempo_promedio}}</td>
						<td><a href="" v-on:click.prevent="editDetalleCaso(detalle)"><i class="glyphicon glyphicon-pencil" aria-hidden="true"></i></a></td>
						<td><a href="" v-on:click.prevent="deleteDetalleCaso(detalle.id)"><i class="glyphicon glyphicon-trash" aria-hidden="true"></i></a></td>
					</tr>
				</table>
			</div>
		</div>
		<?php echo $__env->make("admin.detalle_caso.create", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make("admin.detalle_caso.edit", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<script type="text/javascript" src="<?php echo e(asset('js/controller/DetalleCasoController.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>