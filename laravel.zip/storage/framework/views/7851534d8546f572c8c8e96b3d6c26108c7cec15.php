<?php $__env->startSection("content"); ?>
<div class="container">
    <a href="#myModal" data-target="#myModal" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
     <form method="post" action="<?php echo e(route('Opciones.store')); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="modal fade" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <h4>Nueva Opcion</h4>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">
                                <div class="form-group row">
                                    <div class="form-group row" style="margin-left: 20px;">
                                        <label  class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Actividad')); ?></label>
                                        <div class="col-md-6">
                                            <select name="actividad" class="form-control" >
                                                <?php $__currentLoopData = $actividad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($values->id); ?>"><?php echo e($values->descripcion); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                   </div>
                                    <div class="form-group row" style="margin-left: 20px;">
                                        <label  class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Descripcion')); ?></label>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control" v-model="descripcion" name="descripcion">
                                        </div>
                                    </div>
                                    <p><input  type="submit"  value="Guardar"  class="btn btn-info" style="margin-left: 300px;"></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                                </div>
                            </div>
                        </div>
                    </div>        
                </div>
            </div>
        </div>
    </form>
    <h3>Opciones</h3>

    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
    <br><br>
    <table class="table table-striped table-bordered table-responsive">
        <thead>
            <tr>
                <th>Id</th>
                <th>Actividad</th>
                <th>Descripcion</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $opcion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($values->id); ?></td>
                    <td><?php echo e($values->id_actividad); ?></td>
                    <td><?php echo e($values->descripcion); ?></td>
                    <td>
                    <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                        <a class="btn btn-small btn-info" id="opciones" data-id="<?php echo e($values->id); ?>" data-acti="<?php echo e($values->id_actividad); ?>" data-descri="<?php echo e($values->descripcion); ?>"  data-toggle="modal" data-target="#opcion"  href="#">Editar</a>
                        <a class="btn btn-small btn-danger" href="<?php echo e(url('administrador/Opciones/delete', $values->id)); ?>">Eliminar</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo $__env->make("Administrador.Opciones.update", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>