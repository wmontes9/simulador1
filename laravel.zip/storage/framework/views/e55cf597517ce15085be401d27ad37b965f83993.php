<form method="post" action="<?php echo e(route('users.store')); ?>" id="formCreateUser">
    <div class="form-group row">  
     <?php echo e(csrf_field()); ?>

      <div class="modal fade" id="crearUser">
        <div class="modal-dialog">
           <div class="modal-content">
             <div class="panel panel-primary">
              <div class="panel-heading">
                   <h4>Crear Usuarios</h4>
                </div>
                  <div class="modal-body">
                      <div class="card-body">
                          <div class="form-group row" style="margin-left: 20px;">
                                  <label  class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Tipo Documento')); ?></label>
                            
                                  <div class="col-md-6">
                        
                                    <select name="tipodocumento" class="form-control" >
                                    <?php $__currentLoopData = $tipodocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                      <option value="<?php echo e($values->id); ?>"><?php echo e($values->nombre_documento); ?></option>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </select>
                                  </div>
                           </div>
                          <div class="form-group row" style="margin-top: 20px;">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Nombre')); ?></label>
                            <div class="col-md-4">
                                  <input type="text" class="form-control"  id="name" name="name">
                            </div>
                          </div>

                          <div class="form-group row">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Apellido')); ?></label>
                            <div class="col-md-4">
                                  <input type="text" class="form-control"  id="apellido" name="apellido">
                            </div>
                          </div>

                          <div class="form-group row">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Documento')); ?></label>
                            <div class="col-md-4">
                                  <input type="text" class="form-control"  id="documento" name="documento">
                            </div>
                          </div>
                   
                          <div class="form-group row">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Contraseña')); ?></label>
                            <div class="col-md-4">
                                  <input type="password" class="form-control"  id="password" name="password">
                            </div>
                          </div>

                          <div class="form-group row">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Estado')); ?></label>
                              <div class="col-md-4">      
                                <select name="estado" id="estado" class="form-control">
                                     <option value="activo">Activo</option>
                                     <option value="inactivo">Inactivo</option>
                                </select>
                              </div>
                          </div>

                          <div class="form-group row">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Telefono')); ?></label>
                            <div class="col-md-4">
                                  <input type="text" class="form-control"  id="telefono" name="telefono">
                            </div>
                          </div>

                          <div class="form-group row">
                                    <label  class="col-sm-4 col-form-label text-md-right"  style="margin-left: 100px;"><?php echo e(__('Email')); ?></label>
                            <div class="col-md-4">
                                  <input type="text" class="form-control"  id="email" name="email">
                            </div>
                          </div>
                          <p><input type="submit" value="Guardar" class="btn btn-info btn-block"></p>
                      </div>
                   </div>
               </div>        
            </div>
          </div>
       </div>
    </div>
</form>
