<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row text-center">
        <h3>Usuarios</h3>
    </div>  
<a href="#crearUser" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
<?php echo $__env->make("Users.create", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- will be used to show any messages -->
<?php if(Session::has('message')): ?>
    <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
<?php endif; ?>
<div class="container-fluid">
<table class="table table-striped table-bordered">
    <thead>
        <tr>
            
            <th>Tipo Documento</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Documento</th>
            <th>Estado</th>
            <th>Telefono</th>
            <th>Email</th>
            <th>Tipo Usuario</th>
            <th>Ficha</th>
            <th colspan="2">Opciones</th>
        </tr>
    </thead>
    <tbody>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <!--  --> 
            <td><?php echo e($usuario->nombre); ?></td>
            <td><?php echo e($usuario->name); ?></td>
            <td><?php echo e($usuario->apellido); ?></td>
            <td><?php echo e($usuario->documento); ?></td>
            <td><?php echo e($usuario->estado); ?></td>
            <td><?php echo e($usuario->telefono); ?></td>
            <td><?php echo e($usuario->email); ?></td>
            <td><?php echo e($usuario->tipousuarios); ?></td>
            <td></td>
            <td>
              <a class="btn btn-small btn-info" id="edituser" data-id="<?php echo e($usuario->id); ?>" data-tipo="<?php echo e($usuario->tipodocumento); ?>" data-nombre="<?php echo e($usuario->name); ?>" data-apellido="<?php echo e($usuario->apellido); ?>" data-documento="<?php echo e($usuario->documento); ?>" data-password="<?php echo e($usuario->password); ?>" data-estado="<?php echo e($usuario->estado); ?>" data-telefono="<?php echo e($usuario->telefono); ?>" data-email="<?php echo e($usuario->email); ?>" data-rol="<?php echo e($usuario->tipousuarios); ?>" data-toggle="modal" data-target="#editarUser" href="#">Editar</a> 
            </td>
            <td>
              <a class="btn btn-small btn-danger" href="<?php echo e(url('administrador/users/delete',
              $usuario->id)); ?>">Eliminar</a>   
            </td>            
        </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo $__env->make("Users.update", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>