<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="row text-center">
            <h3>Actividades</h3>
        </div>  
        <a href="#myModal" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
        <form method="post" action="<?php echo e(route('actividad.store')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="modal fade" id="myModal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h4>Nueva Actividad</h4>
                            </div>
                            <div class="modal-body">
                                <div class="card-body">
                                    <div class="form-group row">
                                        <div class="form-group row" style="margin-left: 20px;">
                                            <label  class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Resultado')); ?></label>
                                        
                                            <div class="col-md-6">
                                                <select name="resultado" class="form-control" >
                                                <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($values->id); ?>"><?php echo e($values->descripcion); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row" style="margin-left: 20px;">
                                                <label  class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Descripcion')); ?></label>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" v-model="descripcion" name="descripcion">
                                            </div>
                                        </div>
                                            <div class="form-group row" style="margin-left: 20px;">
                                                <label  class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Estado')); ?></label>
                                            <div class="col-md-6">
                                            <select name="estado" class="form-control" >
                                                <option value="Activo">Activo</option>
                                                <option value="Inactivo">Inactivo</option>
                                            </select>
                                            </div>
                                        </div>
                                        <p><input  type="submit"  value="Guardar"  class="btn btn-info" style="margin-left: 300px;"></p>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                                    </div>
                                </div>
                            </div>
                        </div>        
                    </div>
                </div>
            </div>
        </form>
        <!--<a class="navbar-brand btn btn-primary pull-right"  href="<?php echo e(route('evaluacion.index')); ?>">Evaluacion</a>-->
        <br>
        <!-- will be used to show any messages -->
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <br><br>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Anexos</th>
                    <th>Id</th>
                    <th>Resultado</th>
                    <th>Descripcion</th>
                    <th>Estado</th>
                    <th>Opciones</th>
                    
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $actividad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="width:40px"><button class="btn btn-warning show_anexo" data-id="<?php echo e($value->id); ?>">Ver</button></td>
                    <td><?php echo e($value->id); ?></td>
                    <td><?php echo e($value->nombre); ?></td>
                    <td><?php echo e($value->descripcion); ?></td>
                    <td><?php echo e($value->estado); ?></td>
                    <td>
                    <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                        <a class="btn btn-small btn-info" id="edita" data-id="<?php echo e($value->id); ?>" data-resul="<?php echo e($value->idresultado); ?>" data-estado="<?php echo e($value->estado); ?>" data-desc="<?php echo e($value->descripcion); ?>" data-toggle="modal" data-target="#editar" href="#">Editar</a>
                        <a class="btn btn-small btn-success anexo" data-id="<?php echo e($value->id); ?>"   href="#">Anexar</a>
                        <a class="btn btn-small btn-danger" href="<?php echo e(url('administrador/actividad/delete', $value->id)); ?>">Eliminar</a>

                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

        </table> 

        <?php echo $__env->make("Administrador/AnexoActi.index", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make("Administrador/AnexoActi.anexo_actividad", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>