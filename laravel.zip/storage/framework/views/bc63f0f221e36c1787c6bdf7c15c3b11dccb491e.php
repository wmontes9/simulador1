<?php $__env->startSection("content"); ?>
<div class="row" id="appControllerRespuesta">
    <div class="container">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <a href="#newRespuesta" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
            <div class="clearfix"></div>
            <table class="table table-bordered" style="margin-top: 10px;">
                <tr>
                    <th>Id</th>
                    <th>Descripción</th>
                    <th>Validación</th>
                    <th colspan="6" class="">Opciones</th>
                </tr>
                <tr v-for="respuesta in respuestas">
                    <td>{{respuesta.id}}</td>
                    <td>{{respuesta.descripcion}}</td>
                    <td>{{respuesta.validacion}}</td>
                    <td><a href="" v-on:click.prevent="editrespuesta(respuesta)"><i class="glyphicon glyphicon-pencil" aria-hidden="true"></i></a></td>
                    <td><a href="" v-on:click.prevent="deleterespuesta(respuesta.id)"><i class="glyphicon glyphicon-trash" aria-hidden="true"></i></a></td>
                </tr>
            </table>
        </div>
    
    </div>
    <?php echo $__env->make("admin.respuesta.create", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("admin.respuesta.edit", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<script type="text/javascript" src="<?php echo e(asset('js/controller/respuestaController.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>