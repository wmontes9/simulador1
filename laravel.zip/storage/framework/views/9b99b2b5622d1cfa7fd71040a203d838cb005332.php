
<form method="POST" action="<?php echo e(route('anexo.store')); ?>" id="formEditAct">
    <?php echo e(csrf_field()); ?>

    <div class="modal fade" id="anexo">
      <div class="modal-dialog">
        <div class="modal-content">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h4>Anexar </h4>
                </div>
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <form action="">
                        <input type="hidden" name="idActividad" value="">
                 <fieldset>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/remision')); ?>"><a href="<?php echo e(url('AnexoActi/remision')); ?>">Remision</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/debito')); ?>"><a href="<?php echo e(url('AnexoActi/debito')); ?>">Nota Debito</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/credito')); ?>"><a href="<?php echo e(url('AnexoActi/credito')); ?>">Nota Credito</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/caja')); ?>"><a href="<?php echo e(url('AnexoActi/caja')); ?>">Recibo de Caja</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/salida')); ?>" ><a href="<?php echo e(url('AnexoActi/salida')); ?>">Salida de Almacen</a><br></td>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/nota')); ?>"><a href="<?php echo e(url('AnexoActi/nota')); ?>">Nota de Contabilidad</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/cajamenor')); ?>"><a href="<?php echo e(url('AnexoActi/cajamenor')); ?>">Recibo de Caja Menor</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/diario')); ?>"><a href="<?php echo e(url('AnexoActi/diario')); ?>">Comprobante Diario</a><br> </td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/egreso')); ?>"><a href="<?php echo e(url('AnexoActi/egreso')); ?>">Comprobante de Egreso</a><br></td>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/ingreso')); ?>"><a href="<?php echo e(url('AnexoActi/ingreso')); ?>">
                      Comprobante de Ingreso</a><br></td>
                    <tr>
                      <td><input type="checkbox" name="anexo[]" value="<?php echo e(url('AnexoActi/formulario')); ?>"><a href="<?php echo e(url('AnexoActi/formulario')); ?>">Hoja de vida equipos de Computo</a><br></td></td>
                    </tr>
                    </fieldset>
                  </form>
                    </tr>
                  </tbody>
                </table>
                
                    <div class="modal-body">
                        <div class="card-body">
                            <div class="form-group row">
                              <p><input  type="submit"  value="Guardar"  class="btn btn-info text-center" style="margin-left: 300px;"></p>
                        </div>
                     <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                  </div>
                </div>
             </div>
       </div>        
    </div>
</div>
</div>
</form>

