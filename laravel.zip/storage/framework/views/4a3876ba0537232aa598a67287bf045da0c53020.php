<form action="<?php echo e(route('detalle.store')); ?>" method="post">
	<?php echo e(csrf_field()); ?>

	<div class="modal fade" id="newDetalleCaso">
		<div class="modal-dialog">
			<div class="modal-content">
                <div class="modal-header">
                    <button class="close" data-dismiss="modal">&times;</button>
                    <h2 class="text-center">Detalle caso</h2>
                </div>
				<div class="modal-body">
					<!--<input type="hidden" value="<?php echo e(Session::get('competencia')); ?>" name="id_competencia">-->
					<div class="form-group">
                        <label for="">Proposito</label>
                        <textarea class="form-control" rows="2" name="proposito" v-model="proposito">
                        </textarea>
						<?php if($errors->has("proposito")): ?>
							<p class="text-danger"><?php echo e($errors->first("proposito")); ?></p>
						<?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">Audiencia</label>
                        <textarea class="form-control" rows="2" name="audiencia" v-model="audiencia">
                        </textarea>
						<?php if($errors->has("audiencia")): ?>
							<p class="text-danger"><?php echo e($errors->first("audiencia")); ?></p>
						<?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">Enfoque</label>
                        <textarea class="form-control" rows="2" name="enfoque" v-model="enfoque">
                        </textarea>
						<?php if($errors->has("enfoque")): ?>
							<p class="text-danger"><?php echo e($errors->first("enfoque")); ?></p>
						<?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">Metodo</label>
                        <textarea class="form-control" rows="2" name="metodo" v-model="metodo">
                        </textarea>
						<?php if($errors->has("metodo")): ?>
							<p class="text-danger"><?php echo e($errors->first("metodo")); ?></p>
						<?php endif; ?>
                    </div>
                    <div class="form-group">
						<label for="">Fecha elaboración</label>
						<input type="date" name="fecha_elaboracion" v-model="fecha_elaboracion" class="form-control">
						<?php if($errors->has("fecha_elaboracion")): ?>
							<p class="text-danger"><?php echo e($errors->first("fecha_elaboracion")); ?></p>
						<?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">Estado</label>
                        <select class="form-control" name="estado" v-model="estado">
                            <option value="0">--Seleccionar--</option>
                            <option value="1">Activo</option>
                            <option value="2">Inactivo</option>
                        </select>
						<?php if($errors->has("estado")): ?>
							<p class="text-danger"><?php echo e($errors->first("estado")); ?></p>
						<?php endif; ?>
                    </div>
                    <div class="form-group">
						<label for="">Tiempo promedio</label>
						<input type="text" name="tiempo_promedio" v-model="tiempo_promedio" class="form-control">
						<?php if($errors->has("tiempo_promedio")): ?>
							<p class="text-danger"><?php echo e($errors->first("tiempo_promedio")); ?></p>
						<?php endif; ?>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-success">Crear</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>