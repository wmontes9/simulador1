<?php $__env->startSection("content"); ?>
<div class="row" id="appControllerCuestionario">
    <div class="container">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <a href="#newCuestionario" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
            <div class="clearfix"></div>
            <table class="table table-bordered" style="margin-top: 10px;">
                <tr>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Descripción</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Duración</th>
                    <th colspan="6" class="">Opciones</th>
                </tr>
                <tr v-for="cuestionario in cuestionarios">
                    <td>{{cuestionario.id}}</td>
                    <td>{{cuestionario.titulo}}</td>
                    <td>{{cuestionario.descripcion}}</td>
                    <td>{{cuestionario.fecha_cuestionario}}</td>
                    <td>{{cuestionario.estado}}</td>
                    <td>{{cuestionario.duracion}}</td>
                    <td><a href="" v-on:click.prevent="getPreguntas(cuestionario.id)">Preguntas</a></td>
                    <td><a href="" v-on:click.prevent="editCuestionario(cuestionario)"><i class="glyphicon glyphicon-pencil" aria-hidden="true"></i></a></td>
                    <td><a href="" v-on:click.prevent="deleteCuestionario(cuestionario.id)"><i class="glyphicon glyphicon-trash" aria-hidden="true"></i></a></td>
                </tr>
            </table>
        </div>
    
    </div>
    <?php echo $__env->make("admin.cuestionario.create", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make("admin.cuestionario.edit", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<script type="text/javascript" src="<?php echo e(asset('js/controller/CuestionarioController.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>