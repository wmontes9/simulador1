<?php $__env->startSection("content"); ?>
<div class="container">
        <div class="col-md-12 text-center">
                <p><h4>Descripcion:  <?php $__currentLoopData = $caso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($fil->titulo); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h4></p>
                <p style="text-align: justify;">
                        <?php $__currentLoopData = $caso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <textarea style="width:100%;" rows="14"><?php echo e($fil->descripcion); ?></textarea>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
        </div>
</div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make("layouts.app_aprendiz", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>