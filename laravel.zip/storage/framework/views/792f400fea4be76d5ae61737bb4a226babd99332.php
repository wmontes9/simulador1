<?php $__env->startSection("content"); ?>
	<div class="row" id="appControllerObjetivo">
		<div class="container">
			<div class="col-xs-12 col-sm-12 col-md-12">
				<!--<input type="hidden" id="idCentro" value="<?php echo e(Session::get('id_center')); ?>"  name="id_center">-->
				<a href="#newobjetivoCaso" data-toggle="modal" class="btn btn-primary pull-right">Nuevo</a>
				<div class="clearfix"></div>
				<table class="table table-bordered" style="margin-top: 10px;">
					<tr>
						<td>Id</td>
                        <td>Id_Caso</td>
						<td>Descripción</td>
						<td colspan="3">Opciones</td>
					</tr>
					<tr v-for="objetivo in objetivos">
						<td>{{objetivo.id}}</td>
                        <td>{{objetivo.id_caso}}</td>
						<td>{{objetivo.descripcion}}</td>
						<td><a href="" v-on:click.prevent="editobjetivoCaso(objetivo)"><i class="glyphicon glyphicon-pencil" aria-hidden="true"></i></a></td>
						<td><a href="" v-on:click.prevent="deleteobjetivoCaso(objetivo.id)"><i class="glyphicon glyphicon-trash" aria-hidden="true"></i></a></td>
					</tr>
				</table>
			</div>
		</div>
		<?php echo $__env->make("admin.objetivo.create", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->make("admin.objetivo.edit", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>
	<script type="text/javascript" src="<?php echo e(asset('js/controller/ObjetivoController.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app_admin", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>