<?php $__env->startSection("content"); ?>
<div class="col-md-12 text-center">
        <p><h4>Audiencia:  <?php $__currentLoopData = $caso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($fil->titulo); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h4></p>
        <p>
                <?php $__currentLoopData = $caso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			
				<div class="col-md-12 col-xs-4 border border-success">
                    <p> <?php echo e($fil->audiencia); ?>

                    </p>
				</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
	</div>
	<hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app_aprendiz", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>