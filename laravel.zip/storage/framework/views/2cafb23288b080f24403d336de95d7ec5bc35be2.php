<form action="<?php echo e(route('pregunta.store')); ?>" method="post">
	<?php echo e(csrf_field()); ?>

	<div class="modal fade" id="newPregunta">
		<div class="modal-dialog">
			<div class="modal-content">
                <div class="modal-header">
                    <button class="close" data-dismiss="modal">&times;</button>
                    <h2 class="text-center">Pregunta</h2>
                </div>
				<div class="modal-body">
					<!--<input type="hidden" value="<?php echo e(Session::get('competencia')); ?>" name="id_competencia">-->
                    <div class="form-group">
                        <label for="">Descripción</label>
                        <textarea class="form-control" rows="2" name="descripcion" v-model="fillPregunta.descripcion">
						</textarea>
						<?php if($errors->has("descripcion")): ?>
							<p class="text-danger"><?php echo e($errors->first("descripcion")); ?></p>
						<?php endif; ?>
                    </div>
					<div class="form-group">
						<button type="submit" class="btn btn-success">Crear</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>