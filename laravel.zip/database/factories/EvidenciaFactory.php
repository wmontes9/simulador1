<?php

use Faker\Generator as Faker;

$factory->define(App\Evidencia::class, function (Faker $faker) {
    return [
        //
    ];
});
