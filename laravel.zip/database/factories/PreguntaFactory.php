<?php

use Faker\Generator as Faker;

$factory->define(App\Pregunta::class, function (Faker $faker) {
    return [
        //
    ];
});
