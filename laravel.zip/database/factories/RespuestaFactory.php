<?php

use Faker\Generator as Faker;

$factory->define(App\Respuesta::class, function (Faker $faker) {
    return [
        //
    ];
});
