<?php

use Faker\Generator as Faker;

$factory->define(App\Detalle_Ficha::class, function (Faker $faker) {
    return [
        //
    ];
});
