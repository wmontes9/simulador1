<?php

use Faker\Generator as Faker;

$factory->define(App\Cuestionario::class, function (Faker $faker) {
    return [
        //
    ];
});
