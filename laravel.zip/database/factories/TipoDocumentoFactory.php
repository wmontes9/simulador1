<?php

use Faker\Generator as Faker;

$factory->define(App\tipo_documento::class, function (Faker $faker) {
    return [
        //
    ];
});
