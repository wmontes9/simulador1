<?php

use Faker\Generator as Faker;

$factory->define(App\Objetivo::class, function (Faker $faker) {
    return [
        //
    ];
});
