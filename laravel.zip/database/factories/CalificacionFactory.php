<?php

use Faker\Generator as Faker;

$factory->define(App\calificacion::class, function (Faker $faker) {
    return [
        //
    ];
});
