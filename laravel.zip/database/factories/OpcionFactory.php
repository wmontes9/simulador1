<?php

use Faker\Generator as Faker;

$factory->define(App\opcion::class, function (Faker $faker) {
    return [
        //
    ];
});
