<?php

use Faker\Generator as Faker;

$factory->define(App\Anexo::class, function (Faker $faker) {
    return [
        //
    ];
});
