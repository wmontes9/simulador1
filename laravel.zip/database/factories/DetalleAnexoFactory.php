<?php

use Faker\Generator as Faker;

$factory->define(App\Detalle_Anexo::class, function (Faker $faker) {
    return [
        //
    ];
});
