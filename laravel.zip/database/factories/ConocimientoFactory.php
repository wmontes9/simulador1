<?php

use Faker\Generator as Faker;

$factory->define(App\Conocimiento::class, function (Faker $faker) {
    return [
        //
    ];
});
