<?php

use Faker\Generator as Faker;

$factory->define(App\Competencia::class, function (Faker $faker) {
    return [
        //
    ];
});
