<?php

use Faker\Generator as Faker;

$factory->define(App\Ficha::class, function (Faker $faker) {
    return [
        //
    ];
});
