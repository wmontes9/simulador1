<?php

use Faker\Generator as Faker;

$factory->define(App\Conocimiento_Previo::class, function (Faker $faker) {
    return [
        //
    ];
});
