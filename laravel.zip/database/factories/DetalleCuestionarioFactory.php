<?php

use Faker\Generator as Faker;

$factory->define(App\Detalle_Cuestionario::class, function (Faker $faker) {
    return [
        //
    ];
});
