<?php

use Faker\Generator as Faker;

$factory->define(App\Anexo_Actividad::class, function (Faker $faker) {
    return [
        //
    ];
});
